# Critical Path: Naive vs. Optimized Schedule

- **Naive (fully sequential) plan total duration:** 48 working days
- **Optimized (parallelized) plan total duration:** 27 working days
- **Timeline reduction:** 21 days saved (43.8% shorter)

The naive plan ran the 5 regional rollouts (T6-T10) one after another. Since each region has an independent floor team with no shared equipment dependency, they can execute in parallel once training (T5) is complete. Resequencing the plan around this single false dependency accounts for nearly all of the time saved.

| Task | Naive Finish (day) | Optimized Finish (day) |
|---|---|---|
| T1: Define cycle-count methodology and SOP | 4 | 4 |
| T2: Finance sign-off on variance thresholds | 6 | 6 |
| T3: Configure WMS cycle-count module | 11 | 9 |
| T4: Classify SKUs by count-frequency tier (A/B/C) | 14 | 7 |
| T5: Train regional warehouse leads (5 regions) | 17 | 12 |
| T6: North region pilot count | 21 | 16 |
| T7: South region rollout | 25 | 16 |
| T8: East region rollout | 29 | 16 |
| T9: West region rollout | 33 | 16 |
| T10: Central region rollout | 37 | 16 |
| T11: Consolidate variance data across regions | 40 | 19 |
| T12: Reconcile discrepancies above threshold | 43 | 22 |
| T13: Finance audit sign-off | 45 | 24 |
| T14: Publish process documentation and playbook | 47 | 26 |
| T15: Retrospective and improvement review | 48 | 27 |